@extends('layouts.adminapp')
@section('content')
 
   @livewire('admin.cleaner.cleaner')
  
 @endsection  
