@extends('layouts.adminapp')
@section('content')
 
   @livewire('admin.customer.customer')
  
 @endsection  


