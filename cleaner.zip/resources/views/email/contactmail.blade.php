<html>
<head>
    <title>CanaryCleaner</title>
</head>
<body>
    <h1>Hi.</h1>
    <p>Your contact service has been closed.</p>
    <p>Thank you.</p>
    <p>Regards.</p>
</body>
</html>
