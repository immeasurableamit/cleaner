   <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="detail-div-block">
              <h4>Account history log</h4>
              <div class="inner-white-wrapper account-history-log">
                <p>2/24/22 - 11:37 CST TNX OUT23523 <strong>- Payout -</strong> <span class="success">SUCCESS</span> $200</p>
                <p>2/24/22 - 11:37 CST TNX OUT23523 <strong>- Refund -</strong> <span class="success">SUCCESS</span> $200</p>
                <p>2/24/22 - 11:37 CST TNX OUT23523 <strong>- Charge -</strong> <span class="failed">Failed</span> $200</p>
                <p>2/24/22 - 11:37 CST TNX OUT23523 <strong>- Payout -</strong> <span class="success">SUCCESS</span> $200</p>
                <p>2/24/22 - 11:37 CST TNX OUT23523 <strong>- Scheduled -</strong> <span class="scheduled-time">02/14/22</span> $200</p>
              </div>
              </div>
          </div>
