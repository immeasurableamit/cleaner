<div class="prescheduled_section">
                  <form>
                    <div class="form-headeing-second py-3">
                        <h4 class="border-0">Prescheduled Off-Time</h4>
                        <a href="#" class="link-design-2">View common holidays around the world</a>
                        </div>

                      <div class="row ">
                        <div class="col-lg-12 col-xl-9 col-sm-12 col-md-12">
                            <div class="row prescheduled_row">
                                <div class="col-md-6 col-5">
                                    <label>February 22, 2022</label>
                                </div>
                                <div class="col-md-6 col-7 p-0">
                                   <span>All Day</span>
                                   <button class="border-0 bg-none btn_delete"><img src="assets/images//icons/delete_2.svg"></button>
                                </div>
                            </div>
                            <div class="row prescheduled_row">
                                <div class="col-md-6 col-5">
                                    <label>February 22, 2022</label>
                                </div>
                                <div class="col-md-6 col-7 p-0">
                                   <span>9:00am - 2:30pm</span>
                                   <button class="border-0 bg-none btn_delete"><img src="assets/images//icons/delete_2.svg"></button>
                                   <!-- <button class="border-0 bg-none btn_add_more">+</button> -->
                                </div>
                            </div>

                            <div class="append_row_preschduled row">
                              <div class="col-md-4 col-sm-12">
                                <div class="select-design">
                                <select class="form-select select-custom-design" aria-label="Default select example">
                                    <option selected>Select Date</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-md-8 col-sm-12">
                                <div class="preschedule-time-details">
                                <input type="time">
                                <span class="slash">-</span>
                                <input type="time">
                                <!-- <button class="border-0 bg-none btn_delete"><img src="assets/images//icons/delete_2.svg"></button> -->
                                <button class="btn_c">Add</button>
                                </div>
                              </div>
                            </div>
                        </div>
                        
                      </div>
                      <button class="btn_blue mt-4">Save</button>
                    </form>
                 </div>