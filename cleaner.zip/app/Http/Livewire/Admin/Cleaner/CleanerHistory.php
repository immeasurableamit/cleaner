<?php

namespace App\Http\Livewire\Admin\Cleaner;

use Livewire\Component;

class CleanerHistory extends Component
{
    public function render()
    {
        return view('livewire.admin.cleaner.cleaner-history');
    }
}
