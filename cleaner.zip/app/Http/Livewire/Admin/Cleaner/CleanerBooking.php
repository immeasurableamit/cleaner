<?php

namespace App\Http\Livewire\Admin\Cleaner;

use Livewire\Component;

class CleanerBooking extends Component
{
    public function render()
    {
        return view('livewire.admin.cleaner.cleaner-booking');
    }
}
