<?php

namespace App\Http\Livewire\Admin\Customer;

use Livewire\Component;

class CustomerBooking extends Component
{
    public function render()
    {
        return view('livewire.admin.customer.customer-booking');
    }
}
