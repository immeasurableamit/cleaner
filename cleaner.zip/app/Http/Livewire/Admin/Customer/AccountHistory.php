<?php

namespace App\Http\Livewire\Admin\Customer;

use Livewire\Component;

class AccountHistory extends Component
{
    public function render()
    {
        return view('livewire.admin.customer.account-history');
    }
}
