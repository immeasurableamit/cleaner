<?php

namespace App\Http\Livewire\Cleaner;

use Livewire\Component;

class Support extends Component
{
    public function render()
    {
        return view('livewire.cleaner.support');
    }
}
