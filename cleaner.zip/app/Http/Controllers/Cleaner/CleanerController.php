<?php

namespace App\Http\Controllers\Cleaner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class CleanerController extends Controller
{
    
// public function index()
// {
//     $user = User::find(auth()->user()->id);
//     dd($user);
//     return view('cleaner.account', compact('user'));
// }

}
